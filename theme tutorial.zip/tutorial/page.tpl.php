<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!-- Acrescentamos aqui o idioma da pagina e a direção do texto do idioma -->
<html xmlns="http://www.w3.org/1999/xhtml"
xml:lang="<?php print $language->language ?>"

lang="<?php print $language->language ?>" dir="<?php print $language->dir ?>">
<head>
<!-- Removemos a tag meta contendo o tipo do documento e o charset
-- para inserir estas informações de acordo com as configurações
-- informadas ou obtidas pelo Drupal
-->
<?php print $head ?>
<!-- Inserimos o título da página que varia dinamicamento -->
<title><?php print $head_title ?></title>
<!-- Inserimos a importação de folhas de estilos -->
<?php print $styles ?>
<!-- Carregamos os arquivos javascript necessários -->
<?php print $scripts ?>
</head>
<!-- Colocamos uma função na tag BODY
-- que irá criar um atributo class na mesma
-- e controlar o valor deste atributo de acordo
-- com as configurações dos Blocks em uso
-- Esta função foi herdada do tema padrão Garlando
-- no arquivo "template.php"
-->
<body<?php print phptemplate_body_class($left, $right); ?>>
<!-- Layout -->
<div id="externo">
<div id="cabecalho">
<?php /* Imprime o conteudo definido nos Blocks para o Header (cabeçalho) */ ?>
<?php print $header; ?>
<!-- Herdado do Garland -->
<div id="logotipo">
<?php
// Prepara o cabeçalho criando um array com algumas informações do site
$site_fields = array();
// se o nome do site existe
if ($site_name) {
/**
* Codifica caracteres especiais num string de texto puro para exibir o nome do site como HTML.
*/
$site_fields[] = check_plain($site_name);
}
if ($site_slogan) {
/**
* O mesmo que ocorre com o nome do site ocorre com o slogan
*/
$site_fields[] = check_plain($site_slogan);
}
/*
* Une as chaves de $site_fields com espaços para criar o title
*/
$site_title = implode(' ', $site_fields);
/**
* Se todas as informações foram passadas
*/
if ($site_fields) {
// coloca o nome do site entre tags SPAN
$site_fields[0] = '<span>'. $site_fields[0] .'</span>';
}
/*
* Une as chaves de $site_fields com espaços para criar o HTML
*/
$site_html = implode(' ', $site_fields);
// Testa se $logo ou $site_title possuem valor
if ($logo || $site_title) {
// Cria um cabeçalho com o um link para a pagina inicial filtrando-o contra protocolos indesejáveis (XSS)
print '<h1><a href="'. check_url($front_page) .'" title="'. $site_title .'">';
// se o logo existir
if ($logo) {
print '<img src="'. check_url($logo) .'" alt="'. $site_title .'" id="logo" />';
}
// Imprime o HTML com o nome do site final
print $site_html .'</a></h1>';
}
?>
<?php /* Imprime os links primarios se eles existirem */ ?>
<?php if (isset($primary_links)) : ?>
<?php print theme('links', $primary_links, array('class' => 'links primary-links')) ?>
<?php endif; ?>
<?php /* Imprime os links secundários se eles existirem */ ?>
<?php if (isset($secondary_links)) : ?>
<?php print theme('links', $secondary_links, array('class' => 'links secondary-links')) ?>
<?php endif; ?>
</div>
</div><!-- /cabecalho -->

<?php /* Se existir algum Block a ser exibido na esquerda, então esta coluna será montada com o respectivo conteúdo */ ?>
<?php if ($left): ?>
<div id="esquerda">
<?php /* Se a caixa de busca estiver ativada e esta coluna exista, ela aparecerá na esquerda */ ?>
<?php if ($search_box): ?><div class="block block-theme"><?php print $search_box ?></div><?php endif; ?>
<?php print $left ?>
</div><!-- /esquerda -->
<?php endif; ?>

<?php /* Se existir algum Block a ser exibido na esquerda, então esta coluna será montada com o respectivo conteúdo */ ?>
<?php if ($right): ?>
<div id="direita">
<?php /* Se a caixa de busca estiver ativada e a coluna esquerda não exista, ela aparecerá na direita */ ?>
<?php if (!$left && $search_box): ?><div class="block block-theme"><?php print $search_box ?></div><?php endif; ?>
<?php print $right ?>
</div><!-- /direita -->
<?php endif; ?>
<div id="centro">
<?php /* Imprime o breadcrum do site */ ?>
<?php print $breadcrumb; ?>
<?php /* Imprime a missão do site caso ela exista */ ?>
<?php if ($mission): print '<div id="mission">'. $mission .'</div>'; endif; ?>
<?php /* Imprime as tabs das páginas que as usem */ ?>
<?php if ($tabs): print '<div id="tabs-wrapper" class="clear-block">'; endif; ?>
<?php /* Imprime o título do node */ ?>
<?php if ($title): print '<h2'. ($tabs ? ' class="with-tabs"' : '') .'>'. $title .'</h2>'; endif; ?>
<?php if ($tabs): print '<ul class="tabs primary">'. $tabs .'</ul></div>'; endif; ?>
<?php /* Imprime tabs secundarias */ ?>
<?php if ($tabs2): print '<ul class="tabs secondary">'. $tabs2 .'</ul>'; endif; ?>
<?php /* Imprime informações relevantes ao usuário */ ?>
<?php if ($show_messages && $messages): print $messages; endif; ?>

<?php /* Imprime ajuda caso esteja disponível */ ?>
<?php print $help; ?>

<?php /* Imprime todo o conteúdo especificado no Block Content */ ?>
<?php print $content ?>

<?php /* Imprime os feeds da página */ ?>
<?php print $feed_icons ?>
</div><!-- /centro -->
<div id="rodape">
<?php /* Imprime a mensagem do rodapé, e os Blocks selecionados como Footer */ ?>
<?php print $footer_message . $footer ?>
</div><!-- /rodape -->
</div><!-- /externo -->
<?php /* Marcação final de fechamentos diversos */ ?>
<?php print $closure ?>
</body>